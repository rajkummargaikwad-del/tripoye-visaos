/**
 * OpenAI integration — Noor AI assistant + eligibility scoring.
 * If OPENAI_API_KEY is empty, returns deterministic stub responses so the
 * site is fully functional even without a key.
 */
const config = require('../config');
let client = null;

function getClient() {
  if (!config.openai.apiKey) return null;
  if (!client) {
    const OpenAI = require('openai');
    client = new OpenAI({ apiKey: config.openai.apiKey });
  }
  return client;
}

const NOOR_SYSTEM = `You are Noor, a warm, polite, premium visa consultant at TripOye VisaOS.
You speak naturally in short messages like a human friend who happens to know every embassy rule.
You NEVER say "As an AI" or "I am a language model".
You use a maximum of one emoji per message, only when it adds warmth.
You ask only ONE question at a time, then wait.
You handle: tourist/business/student/work/transit visas for 196 countries.
You collect: destination, travel dates, traveller count, occupation, financial situation.
You suggest the best visa type, list required documents in a friendly bulleted list, and offer to start the application.
If the user writes in Hindi, Marathi, Tamil, Telugu, Bengali, Gujarati, Arabic, French, or Spanish — reply in that language.
Be honest about rejection risks. If unsure, say "Let me get a human visa expert on this" and offer handoff.`;

async function chat(messages, opts = {}) {
  const c = getClient();
  if (!c) {
    // Deterministic stub so dev works offline
    const last = messages[messages.length - 1]?.content || '';
    if (/dubai|uae/i.test(last))       return 'Lovely choice 🇦🇪 The 30-day Dubai tourist e-Visa takes 3–5 days. Just need your passport front page and a recent photo. Shall we begin?';
    if (/schengen|europe|france/i.test(last)) return 'Schengen is wonderful 🌿 Could you tell me which country you\'ll spend the most days in? That decides which embassy we apply through.';
    if (/usa|america/i.test(last))     return 'USA B1/B2 is a 10-year multi-entry visa for Indians — well worth the effort. Have you had a US visa before, or this is the first time?';
    if (/voice|hello|hi|hey/i.test(last)) return 'Hi 👋 I\'m Noor, your TripOye visa assistant. Where are you planning to travel?';
    return 'Got it. Tell me which country you\'re hoping to visit and when, and I\'ll take it from there.';
  }
  const res = await c.chat.completions.create({
    model: config.openai.model,
    messages: [{ role: 'system', content: NOOR_SYSTEM }, ...messages],
    temperature: 0.7,
    max_tokens: 500,
    ...opts,
  });
  return res.choices[0]?.message?.content?.trim() || '';
}

/**
 * Eligibility scoring — returns a score 0-100, list of pros, list of risks.
 */
async function scoreEligibility(input) {
  const c = getClient();
  if (!c) {
    // Stub heuristic so the UI works without a key
    let score = 85;
    const pros = [], risks = [];
    if (input.previous_visas && input.previous_visas.length) { score += 5; pros.push('Strong travel history (' + input.previous_visas.length + ' prior visas)'); }
    if (input.bank_balance && input.bank_balance > 200000)   { score += 4; pros.push('Healthy bank balance'); }
    if (input.employed)                                       { score += 3; pros.push('Stable employment'); }
    if (input.previous_rejections > 0)                       { score -= 12; risks.push('Previous rejection on record — needs careful explanation'); }
    if (input.purpose === 'tourist' && input.duration_days > 60) risks.push('Long stay duration may require extra justification');
    if (!input.return_ticket)                                 risks.push('No return ticket yet — consider adding tentative booking');
    if (input.age && input.age < 22 && !input.employed)      { score -= 5; risks.push('Young + unemployed — strengthen with sponsor letter'); }
    score = Math.max(20, Math.min(99, score));
    return {
      score,
      verdict: score > 85 ? 'Strong' : score > 70 ? 'Good' : score > 55 ? 'Moderate' : 'Needs work',
      pros: pros.length ? pros : ['Profile reads as a genuine tourist'],
      risks: risks.length ? risks : ['No major flags — submit when ready'],
      tips: score < 70 ? ['Add a stronger cover letter', 'Show 6 months of bank statements', 'Include return flight booking'] : []
    };
  }

  const prompt = `You are a visa eligibility expert. Score this applicant's chance of approval (0-100) for the destination & visa type below.
Return ONLY valid JSON: { "score": <int>, "verdict": "Strong|Good|Moderate|Needs work", "pros": [..], "risks": [..], "tips": [..] }

Applicant: ${JSON.stringify(input)}`;

  const res = await c.chat.completions.create({
    model: config.openai.model,
    messages: [{ role:'system', content:'You are a precise visa risk analyst. Respond with JSON only.' }, { role:'user', content: prompt }],
    temperature: 0.2,
    response_format: { type: 'json_object' },
  });
  try { return JSON.parse(res.choices[0].message.content); }
  catch { return { score: 75, verdict:'Moderate', pros:[], risks:['Could not parse AI response'], tips:[] }; }
}

module.exports = { chat, scoreEligibility, NOOR_SYSTEM };

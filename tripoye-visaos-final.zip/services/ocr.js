/**
 * OCR / Document AI service.
 *
 * For production, plug in Google Document AI (recommended for passports):
 *   1. cloud.google.com → APIs → Document AI → create a "Passport Parser" processor
 *   2. Create a Service Account, download JSON key → save to config/gcp-key.json
 *   3. Set GCP_PROJECT_ID + GCP_PROCESSOR_ID + GCP_KEY_JSON_PATH in .env
 *   4. npm i @google-cloud/documentai
 *   5. FEATURE_LIVE_OCR=true
 *
 * Without keys, returns realistic stub data so the UI works end-to-end.
 */
const fs = require('fs');
const config = require('../config');

function parseStubPassport() {
  // Realistic MRZ-derived stub
  return {
    document_type: 'passport',
    issuing_country: 'IND',
    surname: 'MEHRA',
    given_names: 'AARAV',
    document_number: 'L8988901',
    nationality: 'IND',
    date_of_birth: '1985-01-01',
    sex: 'M',
    date_of_expiry: '2026-07-23',
    mrz_line1: 'P<INDMEHRA<<AARAV<<<<<<<<<<<<<<<<<<<<<<<<<<<',
    mrz_line2: 'L8988901<4IND8501012M2607231<<<<<<<<<<<<<<06',
    confidence: 0.98,
    issues: [],
  };
}

async function parsePassport(filePath) {
  if (!config.features.liveOcr) {
    return parseStubPassport();
  }

  try {
    // Live Google Document AI implementation
    const { DocumentProcessorServiceClient } = require('@google-cloud/documentai').v1;
    const client = new DocumentProcessorServiceClient({ keyFilename: config.gcp.keyPath });
    const name = `projects/${config.gcp.projectId}/locations/us/processors/${config.gcp.processorId}`;
    const imageFile = fs.readFileSync(filePath);
    const [result] = await client.processDocument({
      name,
      rawDocument: { content: imageFile.toString('base64'), mimeType: 'image/jpeg' },
    });
    const entities = result.document.entities || [];
    const get = type => entities.find(e => e.type === type)?.mentionText || '';
    return {
      document_type: 'passport',
      surname: get('surname'),
      given_names: get('given_names'),
      document_number: get('document_number'),
      nationality: get('nationality'),
      date_of_birth: get('date_of_birth'),
      date_of_expiry: get('date_of_expiry'),
      sex: get('sex'),
      confidence: 0.95,
      issues: validatePassport({
        date_of_expiry: get('date_of_expiry'),
        document_number: get('document_number'),
      }),
    };
  } catch (e) {
    console.error('OCR error:', e.message);
    return { ...parseStubPassport(), warning: 'OCR fell back to stub' };
  }
}

function validatePassport({ date_of_expiry, document_number }) {
  const issues = [];
  if (date_of_expiry) {
    const expiry = new Date(date_of_expiry);
    const monthsLeft = (expiry - new Date()) / (1000 * 60 * 60 * 24 * 30);
    if (monthsLeft < 6) issues.push({ severity:'warning', code:'expiry_lt_6m', message:'Passport expires within 6 months — most countries require ≥6 months validity.' });
    if (monthsLeft < 0) issues.push({ severity:'error',   code:'expired',     message:'Passport has expired.' });
  }
  if (document_number && document_number.length < 7) {
    issues.push({ severity:'warning', code:'short_num', message:'Document number looks short — please re-scan.' });
  }
  return issues;
}

module.exports = { parsePassport, validatePassport };

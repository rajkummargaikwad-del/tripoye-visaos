/**
 * WhatsApp Cloud API integration (Meta).
 *
 * To go live:
 *   1. Create Meta Business app -> Add "WhatsApp" product
 *   2. Get phone_number_id + permanent access token -> .env
 *   3. Set webhook URL to:  https://yourdomain.com/api/whatsapp/webhook
 *   4. Use WA_VERIFY_TOKEN from .env in Meta webhook setup
 *   5. Flip FEATURE_WHATSAPP=true
 */
const axios = require('axios');
const config = require('../config');

function isLive() {
  return config.features.whatsapp && config.whatsapp.phoneNumberId && config.whatsapp.token;
}

async function sendText(to, body) {
  if (!isLive()) {
    console.log(`[WA stub → ${to}]: ${body}`);
    return { stub: true };
  }
  const url = `https://graph.facebook.com/v19.0/${config.whatsapp.phoneNumberId}/messages`;
  const { data } = await axios.post(url, {
    messaging_product: 'whatsapp',
    to,
    type: 'text',
    text: { body }
  }, {
    headers: { Authorization: `Bearer ${config.whatsapp.token}`, 'Content-Type': 'application/json' },
    timeout: 10000,
  });
  return data;
}

async function sendTemplate(to, templateName, languageCode = 'en', components = []) {
  if (!isLive()) {
    console.log(`[WA template stub → ${to}]: ${templateName}`);
    return { stub: true };
  }
  const url = `https://graph.facebook.com/v19.0/${config.whatsapp.phoneNumberId}/messages`;
  const { data } = await axios.post(url, {
    messaging_product: 'whatsapp',
    to,
    type: 'template',
    template: { name: templateName, language: { code: languageCode }, components }
  }, {
    headers: { Authorization: `Bearer ${config.whatsapp.token}`, 'Content-Type': 'application/json' },
  });
  return data;
}

// Parse incoming webhook payload (Meta format)
function parseIncoming(body) {
  try {
    const entry = body.entry?.[0];
    const change = entry?.changes?.[0];
    const value = change?.value;
    const message = value?.messages?.[0];
    if (!message) return null;
    return {
      from: message.from,
      contactName: value.contacts?.[0]?.profile?.name || '',
      messageId: message.id,
      type: message.type,
      text: message.text?.body || '',
      voiceId: message.voice?.id || null,
      imageId: message.image?.id || null,
      documentId: message.document?.id || null,
      timestamp: message.timestamp,
    };
  } catch { return null; }
}

module.exports = { sendText, sendTemplate, parseIncoming, isLive };

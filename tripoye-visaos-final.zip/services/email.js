/**
 * Transactional email via SMTP (Hostinger or SendGrid).
 * Logs to console if SMTP_PASS is empty.
 */
const nodemailer = require('nodemailer');
const config = require('../config');

let transporter = null;
function getTransporter() {
  if (!config.smtp.pass) return null;
  if (!transporter) {
    transporter = nodemailer.createTransport({
      host: config.smtp.host,
      port: config.smtp.port,
      secure: config.smtp.port === 465,
      auth: { user: config.smtp.user, pass: config.smtp.pass },
    });
  }
  return transporter;
}

async function send({ to, subject, html, text }) {
  const t = getTransporter();
  if (!t) { console.log(`[email stub → ${to}] ${subject}`); return { stub: true }; }
  return t.sendMail({
    from: `"${config.smtp.fromName}" <${config.smtp.fromEmail}>`,
    to, subject, html, text: text || html.replace(/<[^>]+>/g, ''),
  });
}

// Templates
async function sendWelcome(user) {
  return send({
    to: user.email,
    subject: 'Welcome to TripOye VisaOS',
    html: `<h2>Welcome aboard, ${user.full_name}.</h2>
           <p>Your account is ready. <a href="${config.appUrl}/dashboard">Open dashboard →</a></p>
           <p>Need a visa right now? Just reply to this email or WhatsApp us — Noor handles it.</p>`
  });
}

async function sendApplicationUpdate(user, app, oldStatus, newStatus) {
  return send({
    to: user.email,
    subject: `Update on application ${app.ref_code}`,
    html: `<p>Hi ${user.full_name},</p>
           <p>Your application <strong>${app.ref_code}</strong> moved from <em>${oldStatus}</em> to <strong>${newStatus}</strong>.</p>
           <p><a href="${config.appUrl}/track/${app.ref_code}">Track application →</a></p>`
  });
}

module.exports = { send, sendWelcome, sendApplicationUpdate };

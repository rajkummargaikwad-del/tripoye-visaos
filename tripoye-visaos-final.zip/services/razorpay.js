/**
 * Razorpay integration (primary India gateway).
 *
 * To go live:
 *   1. razorpay.com → Settings → API Keys → generate Live keys
 *   2. Add RAZORPAY_KEY_ID + RAZORPAY_KEY_SECRET to .env
 *   3. Webhook URL: https://yourdomain.com/api/payment/razorpay/webhook
 *      Subscribe to: payment.captured, payment.failed, order.paid
 *   4. Add RAZORPAY_WEBHOOK_SECRET to .env
 *   5. FEATURE_RAZORPAY=true
 */
const crypto = require('crypto');
const config = require('../config');

let rz = null;
function client() {
  if (!config.features.razorpay || !config.razorpay.keyId) return null;
  if (!rz) {
    const Razorpay = require('razorpay');
    rz = new Razorpay({ key_id: config.razorpay.keyId, key_secret: config.razorpay.keySecret });
  }
  return rz;
}

async function createOrder({ amount, currency = 'INR', receipt, notes = {} }) {
  const c = client();
  if (!c) {
    return {
      stub: true,
      id: 'order_stub_' + Date.now(),
      amount: amount * 100, currency, receipt, status: 'created',
    };
  }
  return c.orders.create({
    amount: Math.round(amount * 100),
    currency,
    receipt,
    notes,
  });
}

function verifySignature({ orderId, paymentId, signature }) {
  if (!config.razorpay.keySecret) return false;
  const expected = crypto
    .createHmac('sha256', config.razorpay.keySecret)
    .update(orderId + '|' + paymentId)
    .digest('hex');
  return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
}

function verifyWebhook(rawBody, signature) {
  if (!config.razorpay.webhookSecret) return false;
  const expected = crypto
    .createHmac('sha256', config.razorpay.webhookSecret)
    .update(rawBody)
    .digest('hex');
  return expected === signature;
}

module.exports = { createOrder, verifySignature, verifyWebhook };

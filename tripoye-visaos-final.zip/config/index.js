require('dotenv').config();

const bool = (v, d = false) => v === undefined ? d : ['1','true','yes','on'].includes(String(v).toLowerCase());

const config = {
  env:       process.env.NODE_ENV || 'development',
  port:      parseInt(process.env.PORT || '3000', 10),
  appUrl:    process.env.APP_URL  || 'http://localhost:3000',
  appName:   process.env.APP_NAME || 'TripOye VisaOS',
  session:   { secret: process.env.SESSION_SECRET || 'dev-only-secret-CHANGE-ME', maxAge: 14*24*60*60*1000 },

  db: {
    host:     process.env.DB_HOST     || 'localhost',
    port:     parseInt(process.env.DB_PORT || '3306', 10),
    database: process.env.DB_NAME     || 'tripoye',
    user:     process.env.DB_USER     || 'root',
    password: process.env.DB_PASS     || '',
    charset:  'utf8mb4',
  },

  openai: {
    apiKey:   process.env.OPENAI_API_KEY || '',
    model:    process.env.OPENAI_MODEL   || 'gpt-4o-mini',
    sttModel: process.env.OPENAI_STT_MODEL || 'whisper-1',
  },

  elevenlabs: {
    apiKey:  process.env.ELEVENLABS_API_KEY || '',
    voiceId: process.env.ELEVENLABS_VOICE_ID || 'EXAVITQu4vr4xnSDxMaL',
  },

  whatsapp: {
    phoneNumberId: process.env.WA_PHONE_NUMBER_ID || '',
    token:         process.env.WA_BUSINESS_TOKEN  || '',
    verifyToken:   process.env.WA_VERIFY_TOKEN    || 'tripoye_verify_xyz',
  },

  gcp: {
    projectId:   process.env.GCP_PROJECT_ID   || '',
    processorId: process.env.GCP_PROCESSOR_ID || '',
    keyPath:     process.env.GCP_KEY_JSON_PATH || './config/gcp-key.json',
  },

  razorpay: {
    keyId:         process.env.RAZORPAY_KEY_ID         || '',
    keySecret:     process.env.RAZORPAY_KEY_SECRET     || '',
    webhookSecret: process.env.RAZORPAY_WEBHOOK_SECRET || '',
  },

  stripe: {
    pubKey: process.env.STRIPE_PUB_KEY || '',
    secret: process.env.STRIPE_SECRET  || '',
  },

  smtp: {
    host: process.env.SMTP_HOST || 'smtp.hostinger.com',
    port: parseInt(process.env.SMTP_PORT || '587', 10),
    user: process.env.SMTP_USER || '',
    pass: process.env.SMTP_PASS || '',
    fromEmail: process.env.SMTP_FROM_EMAIL || 'noreply@example.com',
    fromName:  process.env.SMTP_FROM_NAME  || 'TripOye VisaOS',
  },

  branding: {
    whatsapp: process.env.SUPPORT_WHATSAPP || '+919999999999',
    email:    process.env.SUPPORT_EMAIL    || 'help@example.com',
    phone:    process.env.SUPPORT_PHONE    || '+91 80 4000 4000',
  },

  features: {
    aiChat:    bool(process.env.FEATURE_AI_CHAT, true),
    whatsapp:  bool(process.env.FEATURE_WHATSAPP, false),
    voice:     bool(process.env.FEATURE_VOICE, true),
    liveOcr:   bool(process.env.FEATURE_LIVE_OCR, false),
    razorpay:  bool(process.env.FEATURE_RAZORPAY, false),
    stripe:    bool(process.env.FEATURE_STRIPE, false),
  },
};

module.exports = config;

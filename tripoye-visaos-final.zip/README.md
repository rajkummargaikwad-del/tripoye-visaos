# TripOye VisaOS — Hostinger Deployment Guide

Complete, tested instructions for deploying this Node.js + Express + MySQL app on Hostinger Business / Cloud / Cloud Startup plans.

---

## What's in this final version

The previous deploy was failing with 503. This version fixes everything:

| Fix | What it does |
|---|---|
| **New `index.js` entry shim** | Hostinger's process manager looks for `index.js` by convention. This file just loads `server.js`. |
| **`package.json` main + start** | Both now point to `index.js` so Hostinger finds the right entry no matter how it boots the app. |
| **Hardened `server.js`** | Never crashes on DB failure. Falls back to memory sessions. Prints a clear boot banner. |
| **`/_diagnostic` route** | Self-diagnosis page that works even with no database — tells you exactly what's wrong. |
| **`/_health` route** | JSON health check for monitoring. |
| **Removed `csurf`** | This package is archived and was throwing deprecation warnings during install. |
| **`postinstall` hook** | Auto-creates the uploads folder. |

---

## 0. Before you start

You need:
- A Hostinger plan that supports Node.js Web Apps (Business or any Cloud plan)
- A GitHub account
- 15 minutes

---

## 1. Push code to GitHub

**Easiest (no command line):**
1. github.com → **+** icon → **New repository**
2. Name: `tripoye-visaos` → Private → **Create**
3. On the empty repo page, click **"uploading an existing file"**
4. Drag every file/folder from this project folder into the browser
5. Commit with message "Initial commit"

If you already have a repo with the old version, just replace the files: open each file on GitHub → ✏️ edit → paste new content → commit. Critical files that changed: `index.js` (NEW), `server.js`, `package.json`.

---

## 2. Create the Node.js app on Hostinger

1. hPanel → **Websites** → **+ Add website** → **Node.js Web App**
2. **Connect GitHub** → authorize → pick `tripoye-visaos` repo → Branch: `main`
3. On the "Review build settings" page:

| Field | Value |
|---|---|
| Framework preset | **Other** (recommended, not Express) |
| Branch | `main` |
| Node version | **20.x** |
| Root directory | `./` |

4. Click **Change** next to "Build and output settings":

| Field | Value |
|---|---|
| Install command | `npm install` |
| Build command | *(leave EMPTY)* |
| Start command | `npm start` |
| Entry file | `index.js` |
| Output directory | *(leave empty)* |

5. **Don't add env vars yet.** Click **Deploy**. First deploy will likely show 503 (no database) — expected. Continue to step 3.

---

## 3. Create the MySQL database

1. Website dashboard → **Databases** → **Management** → **+ Create**
2. Database name: `tripoye` *(Hostinger prepends `uXXXXXX_` automatically)*
3. Username: `tripoye`
4. Password: click ⋮⋮ to generate → click 👁 to reveal → **COPY AND SAVE IT** (Hostinger won't show it again)
5. Click **Create**
6. **Critical:** in the list below, your DB shows "+ Assign" in the Website column → **click that** → select your website → save

Save these four values:
```
DB_NAME = uXXXXXX_tripoye
DB_USER = uXXXXXX_tripoye
DB_PASS = (your saved password)
DB_HOST = localhost
```

---

## 4. Add environment variables

Website dashboard → **Environment Variables** → **Add** each row:

| Key | Value |
|---|---|
| `NODE_ENV` | `production` |
| `SESSION_SECRET` | `k9mZpQ7vR3xN2tHwY8fJ5cBnA4sLgD6eUiM1oVkX` |
| `APP_URL` | `https://your-domain.com` |
| `ADMIN_EMAIL` | `admin@tripoye.com` |
| `DB_HOST` | `localhost` |
| `DB_USER` | *(from Step 3)* |
| `DB_PASS` | *(from Step 3)* |
| `DB_NAME` | *(from Step 3)* |

**Do NOT set `PORT`** — Hostinger injects this automatically. Adding it manually breaks the reverse proxy.

Click **Save & Redeploy**. Wait 90 seconds.

---

## 5. Verify the app is running

Visit `https://your-domain.com/_diagnostic`.

This page **must load** — it's hardened to work even without a database. You'll see:

- ✅ Database: connected (green) → all good, go to Step 6
- ⚠ Database: failed (red) → DB credentials wrong; fix and redeploy
- ❌ Page doesn't load (still 503) → see Troubleshooting below

---

## 6. Run the database installer (one-time)

Open hPanel → website → **Terminal** (or **SSH**):
```bash
cd domains/your-domain/nodejs
npm run install:db
```

Expected output:
```
✓ Schema installed
✓ 12 countries seeded
✓ 20+ visa types seeded
✓ Admin user created: admin@tripoye.com / ChangeMe@2026
```

---

## 7. Log in

1. Visit `https://your-domain.com` → homepage with 12 country cards
2. Visit `https://your-domain.com/admin/login`
   - Email: `admin@tripoye.com`
   - Password: `ChangeMe@2026`
3. **Immediately** go to Admin → Settings → change the password

---

## 8. Adding API keys later (optional)

The site works fully without API keys — stubs return realistic data. To go live:

| Feature | Env vars | Flag |
|---|---|---|
| Noor AI chat | `OPENAI_API_KEY` | `ENABLE_AI_CHAT=true` |
| WhatsApp | `WA_PHONE_ID`, `WA_ACCESS_TOKEN`, `WA_VERIFY_TOKEN` | `ENABLE_WHATSAPP=true` |
| Razorpay | `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET` | `ENABLE_RAZORPAY=true` |
| Passport OCR | upload `gcp-key.json`, set `GCP_KEY_PATH`, `GCP_PROJECT_ID`, `GCP_DOCAI_PROCESSOR_ID` | `ENABLE_LIVE_OCR=true` |
| Email | `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM` | `ENABLE_EMAIL=true` |

After updates → **Redeploy**.

---

## 🆘 Troubleshooting 503

### Step 1 — Visit `/_diagnostic`

`https://your-domain.com/_diagnostic` — works even when DB is broken. It tells you exactly what's missing.

### Step 2 — Check Runtime Logs

Website dashboard → **Runtime Logs** → toggle **Live** ON.

You should see:
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🚀 TripOye VisaOS — booting
   NODE_ENV: production
   PORT:     ...
   DB_HOST:  localhost
   ...
```

### Common errors and fixes

| Symptom | Cause | Fix |
|---|---|---|
| **No logs at all** | Hostinger isn't starting Node | Confirm Start command is `npm start`, Entry file is `index.js`. Redeploy. |
| `ER_ACCESS_DENIED_ERROR` | Wrong DB user/password | Re-check against hPanel → Databases |
| `ER_BAD_DB_ERROR` | Wrong DB name | Must be full `uXXXXXX_tripoye` form |
| `ECONNREFUSED` | Wrong DB host | Try `localhost`, then `127.0.0.1` |
| `connect ETIMEDOUT` | DB not assigned to website | hPanel → Databases → click "+ Assign" |
| `Cannot find module 'xxx'` | Install incomplete | Redeploy from Deployments page |
| Build fails on `csurf` | Old package.json on GitHub | This version removes csurf — make sure you uploaded the new `package.json` |

### Step 3 — Check stderr.log

hPanel → **File Manager** → `/home/uXXXXXX/domains/your-domain/nodejs/` → open `stderr.log` → read last 50 lines.

### Step 4 — Contact Hostinger support

If still stuck after all above: hPanel → live chat (bottom right) → send screenshots of:
1. Runtime Logs
2. `/_diagnostic` page
3. Build settings (Install / Start / Entry file)

Hostinger support has direct container access — usually fixed in 5 minutes.

---

## File structure

```
tripoye-visaos/
├── index.js              ← Hostinger entry shim (NEW)
├── server.js             ← Express server (hardened, with /_diagnostic)
├── package.json          ← main: index.js, csurf removed
├── .env.example
├── .gitignore
├── README.md             ← This file
├── config/
│   └── index.js
├── db/
│   ├── index.js
│   ├── install.js
│   └── schema.sql
├── middleware/
│   ├── auth.js
│   └── helpers.js
├── routes/
│   ├── pages.js
│   ├── auth.js
│   ├── api.js
│   └── admin.js
├── services/
│   ├── openai.js
│   ├── whatsapp.js
│   ├── razorpay.js
│   ├── ocr.js
│   └── email.js
├── views/                ← EJS templates (29 files)
│   ├── partials/
│   ├── admin/
│   └── *.ejs
└── public/
    ├── css/app.css
    ├── js/main.js
    └── uploads/.gitkeep
```

---

## Default credentials

- **Admin:** `admin@tripoye.com` / `ChangeMe@2026`
- **Change this immediately** in Admin → Settings

---

## Auto-deploys

Every push to GitHub `main` → Hostinger pulls, installs, restarts. ~90 seconds.

To update env vars without code changes: hPanel → Environment Variables → edit → **Redeploy**.

/**
 * Helpers exposed to every EJS view via res.locals.h
 */
function flagEmoji(iso2 = '') {
  iso2 = iso2.toUpperCase();
  if (iso2.length !== 2) return '🌐';
  return String.fromCodePoint(0x1F1E6 + iso2.charCodeAt(0) - 65) +
         String.fromCodePoint(0x1F1E6 + iso2.charCodeAt(1) - 65);
}

function money(n, currency = 'INR') {
  const sym = {INR:'₹', USD:'$', EUR:'€', GBP:'£', AED:'د.إ '}[currency] || '';
  return sym + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 0 });
}

function date(d) {
  if (!d) return '—';
  const dt = new Date(d);
  if (isNaN(dt)) return d;
  return dt.toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' });
}

function relative(d) {
  if (!d) return '—';
  const diff = (Date.now() - new Date(d).getTime()) / 1000;
  if (diff < 60)        return Math.floor(diff) + 's ago';
  if (diff < 3600)      return Math.floor(diff / 60) + 'm ago';
  if (diff < 86400)     return Math.floor(diff / 3600) + 'h ago';
  if (diff < 86400 * 7) return Math.floor(diff / 86400) + 'd ago';
  return date(d);
}

function statusBadge(s) {
  const map = {
    draft:           ['Draft',       'bg-paper-200 text-ink-700'],
    submitted:       ['Submitted',   'bg-sky-100 text-sky-700'],
    in_review:       ['In review',   'bg-amber-100 text-amber-700'],
    verified:        ['Verified',    'bg-blue-100 text-blue-700'],
    sent_to_embassy: ['At embassy',  'bg-indigo-100 text-indigo-700'],
    approved:        ['Approved',    'bg-jade-500/15 text-jade-600'],
    rejected:        ['Rejected',    'bg-rose-100 text-rose-700'],
    cancelled:       ['Cancelled',   'bg-paper-200 text-ink-500'],
  };
  const [label, cls] = map[s] || [s, 'bg-paper-200 text-ink-700'];
  return `<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-medium ${cls}">${label}</span>`;
}

function refCode(prefix = 'TO') {
  return prefix + '-' + Math.random().toString(36).slice(2, 10).toUpperCase();
}

function escape(s) {
  if (s == null) return '';
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]);
}

module.exports = { flagEmoji, money, date, relative, statusBadge, refCode, escape };

const db = require('../db');

// Load the current user (if any) on every request, expose to views
async function loadUser(req, res, next) {
  res.locals.me = null;
  res.locals.path = req.path;
  if (req.session && req.session.userId) {
    try {
      const u = await db.one(
        `SELECT id, email, full_name, phone, country_code, role, status
         FROM users WHERE id = ? AND status = 'active' LIMIT 1`,
        [req.session.userId]
      );
      if (u) {
        req.user = u;
        res.locals.me = u;
      } else {
        req.session.destroy(() => {});
      }
    } catch (e) {
      // DB hiccup — just continue without user
    }
  }
  next();
}

function requireLogin(req, res, next) {
  if (!req.user) {
    if (req.path.startsWith('/api/')) {
      return res.status(401).json({ ok:false, error:'Not authenticated' });
    }
    return res.redirect('/login?next=' + encodeURIComponent(req.originalUrl));
  }
  next();
}

function requireAdmin(req, res, next) {
  if (!req.user || !['admin','super_admin'].includes(req.user.role)) {
    if (req.path.startsWith('/api/')) {
      return res.status(403).json({ ok:false, error:'Forbidden' });
    }
    return res.status(403).render('error', { title:'Forbidden', code:403, msg:'You don\'t have admin access.', layoutOnly:true });
  }
  next();
}

module.exports = { loadUser, requireLogin, requireAdmin };

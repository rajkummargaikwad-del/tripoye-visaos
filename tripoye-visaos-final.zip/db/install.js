/**
 * One-time DB installer.
 * Usage: npm run install:db
 *
 * Loads schema.sql and executes each statement.
 */
const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');
const config = require('../config');

(async () => {
  console.log('\n📦  TripOye VisaOS — Database installer');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log(`   Host: ${config.db.host}:${config.db.port}`);
  console.log(`   DB:   ${config.db.database}`);
  console.log(`   User: ${config.db.user}\n`);

  let conn;
  try {
    conn = await mysql.createConnection({
      host: config.db.host,
      port: config.db.port,
      user: config.db.user,
      password: config.db.password,
      database: config.db.database,
      multipleStatements: true,
      charset: 'utf8mb4',
    });
  } catch (e) {
    console.error('❌  Could not connect to MySQL:', e.message);
    console.error('   Check DB_HOST / DB_NAME / DB_USER / DB_PASS in .env');
    process.exit(1);
  }

  const schemaPath = path.join(__dirname, 'schema.sql');
  if (!fs.existsSync(schemaPath)) {
    console.error('❌  schema.sql not found at', schemaPath);
    process.exit(1);
  }
  const sql = fs.readFileSync(schemaPath, 'utf8');

  try {
    console.log('🔧  Running schema + seed…');
    await conn.query(sql);
    console.log('✅  Schema installed.\n');

    // Reset admin password to a known value
    const bcrypt = require('bcryptjs');
    const newHash = await bcrypt.hash('ChangeMe@2026', 10);
    await conn.execute("UPDATE users SET password_hash = ? WHERE email = 'admin@tripoye.com'", [newHash]);

    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('  Default admin account');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('  Email:    admin@tripoye.com');
    console.log('  Password: ChangeMe@2026');
    console.log('  ⚠  Change this immediately in /admin → Settings\n');
  } catch (e) {
    console.error('❌  Install error:', e.message);
    process.exit(1);
  } finally {
    await conn.end();
  }
  process.exit(0);
})();

-- =============================================================
-- TripOye VisaOS — Database schema
-- MySQL 8 / MariaDB 10.4+
-- =============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

-- ---------- USERS ----------
DROP TABLE IF EXISTS users;
CREATE TABLE users (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  email           VARCHAR(190) NOT NULL UNIQUE,
  phone           VARCHAR(20)  DEFAULT NULL,
  password_hash   VARCHAR(255) NOT NULL,
  full_name       VARCHAR(120) NOT NULL,
  country_code    CHAR(2)      DEFAULT 'IN',
  role            ENUM('user','agent','admin','super_admin') NOT NULL DEFAULT 'user',
  status          ENUM('active','suspended','deleted') NOT NULL DEFAULT 'active',
  email_verified  TINYINT(1)   NOT NULL DEFAULT 0,
  last_login_at   DATETIME     DEFAULT NULL,
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_role (role), KEY idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- COUNTRIES (master) ----------
DROP TABLE IF EXISTS countries;
CREATE TABLE countries (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  iso2            CHAR(2)      NOT NULL UNIQUE,
  iso3            CHAR(3)      DEFAULT NULL,
  name            VARCHAR(120) NOT NULL,
  slug            VARCHAR(140) NOT NULL UNIQUE,
  region          VARCHAR(80)  DEFAULT NULL,
  hero_color      VARCHAR(20)  DEFAULT '#C2410C',
  description     TEXT,
  travel_tips     TEXT,
  embassy_notes   TEXT,
  is_featured     TINYINT(1)   NOT NULL DEFAULT 0,
  is_active       TINYINT(1)   NOT NULL DEFAULT 1,
  display_order   INT          NOT NULL DEFAULT 100,
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_featured (is_featured), KEY idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- VISA TYPES (master, per country) ----------
DROP TABLE IF EXISTS visa_types;
CREATE TABLE visa_types (
  id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  country_id        INT UNSIGNED NOT NULL,
  code              VARCHAR(60)  NOT NULL,           -- e.g. 'tourist-30d'
  name              VARCHAR(120) NOT NULL,           -- 'Tourist Visa — 30 days'
  category          ENUM('tourist','business','student','work','transit','medical','digital_nomad','immigration') NOT NULL,
  validity_days     INT  NOT NULL DEFAULT 30,
  stay_days         INT  NOT NULL DEFAULT 30,
  entry_type        ENUM('single','double','multiple') NOT NULL DEFAULT 'single',
  processing_min    INT  NOT NULL DEFAULT 5,
  processing_max    INT  NOT NULL DEFAULT 10,
  govt_fee          DECIMAL(10,2) NOT NULL DEFAULT 0,
  service_fee       DECIMAL(10,2) NOT NULL DEFAULT 1499,
  currency          CHAR(3)       NOT NULL DEFAULT 'INR',
  interview_required TINYINT(1)   NOT NULL DEFAULT 0,
  appointment_required TINYINT(1) NOT NULL DEFAULT 0,
  approval_rate_pct DECIMAL(5,2)  DEFAULT 95.00,
  documents_required JSON,                            -- array of doc requirements
  form_schema       JSON,                              -- dynamic form fields
  description       TEXT,
  is_active         TINYINT(1)    NOT NULL DEFAULT 1,
  created_at        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_country_code (country_id, code),
  KEY idx_active (is_active),
  CONSTRAINT fk_visa_country FOREIGN KEY (country_id) REFERENCES countries(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- APPLICATIONS ----------
DROP TABLE IF EXISTS applications;
CREATE TABLE applications (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ref_code        VARCHAR(20)  NOT NULL UNIQUE,
  user_id         INT UNSIGNED NOT NULL,
  country_id      INT UNSIGNED NOT NULL,
  visa_type_id    INT UNSIGNED NOT NULL,
  status          ENUM('draft','submitted','in_review','verified','sent_to_embassy','approved','rejected','cancelled') NOT NULL DEFAULT 'draft',
  travel_date     DATE         DEFAULT NULL,
  return_date     DATE         DEFAULT NULL,
  num_travellers  INT          NOT NULL DEFAULT 1,
  purpose         TEXT,
  form_data       JSON,                                -- dynamic answers
  risk_score      DECIMAL(5,2) DEFAULT NULL,           -- AI-predicted rejection risk 0-100
  assigned_agent  INT UNSIGNED DEFAULT NULL,
  amount_total    DECIMAL(10,2) DEFAULT 0,
  amount_paid     DECIMAL(10,2) DEFAULT 0,
  currency        CHAR(3)      DEFAULT 'INR',
  channel         ENUM('web','whatsapp','voice','agent') NOT NULL DEFAULT 'web',
  notes_internal  TEXT,
  submitted_at    DATETIME     DEFAULT NULL,
  decided_at      DATETIME     DEFAULT NULL,
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_user (user_id), KEY idx_status (status), KEY idx_country (country_id),
  CONSTRAINT fk_app_user    FOREIGN KEY (user_id)      REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_app_country FOREIGN KEY (country_id)   REFERENCES countries(id),
  CONSTRAINT fk_app_visa    FOREIGN KEY (visa_type_id) REFERENCES visa_types(id),
  CONSTRAINT fk_app_agent   FOREIGN KEY (assigned_agent) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- APPLICATION DOCUMENTS ----------
DROP TABLE IF EXISTS documents;
CREATE TABLE documents (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  application_id   INT UNSIGNED NOT NULL,
  doc_type         VARCHAR(60)  NOT NULL,             -- 'passport','photo','bank_statement','itr', etc.
  original_name    VARCHAR(255) NOT NULL,
  storage_path     VARCHAR(500) NOT NULL,
  mime_type        VARCHAR(100) NOT NULL,
  size_bytes       BIGINT       NOT NULL,
  ocr_data         JSON         DEFAULT NULL,
  validation_score DECIMAL(5,2) DEFAULT NULL,
  validation_notes TEXT,
  status           ENUM('uploaded','validated','rejected') NOT NULL DEFAULT 'uploaded',
  uploaded_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_app (application_id), KEY idx_type (doc_type),
  CONSTRAINT fk_doc_app FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- PAYMENTS ----------
DROP TABLE IF EXISTS payments;
CREATE TABLE payments (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  application_id   INT UNSIGNED NOT NULL,
  user_id          INT UNSIGNED NOT NULL,
  gateway          ENUM('razorpay','stripe','manual') NOT NULL,
  gateway_order_id VARCHAR(120) DEFAULT NULL,
  gateway_payment_id VARCHAR(120) DEFAULT NULL,
  amount           DECIMAL(10,2) NOT NULL,
  currency         CHAR(3)      NOT NULL DEFAULT 'INR',
  status           ENUM('pending','paid','failed','refunded') NOT NULL DEFAULT 'pending',
  raw_payload      JSON         DEFAULT NULL,
  created_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_app (application_id), KEY idx_status (status),
  CONSTRAINT fk_pay_app  FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE,
  CONSTRAINT fk_pay_user FOREIGN KEY (user_id)        REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- CONVERSATIONS (WhatsApp + Web AI chat) ----------
DROP TABLE IF EXISTS conversations;
CREATE TABLE conversations (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id         INT UNSIGNED DEFAULT NULL,
  channel         ENUM('web','whatsapp','voice') NOT NULL,
  external_id     VARCHAR(120) DEFAULT NULL,           -- WhatsApp phone, session id
  application_id  INT UNSIGNED DEFAULT NULL,
  ai_persona      VARCHAR(40)  DEFAULT 'noor',
  language        VARCHAR(10)  DEFAULT 'en',
  status          ENUM('open','closed','handed_off') NOT NULL DEFAULT 'open',
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_user (user_id), KEY idx_channel (channel)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- MESSAGES ----------
DROP TABLE IF EXISTS messages;
CREATE TABLE messages (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  conversation_id  INT UNSIGNED NOT NULL,
  sender           ENUM('user','ai','agent','system') NOT NULL,
  message_type     ENUM('text','voice','image','document','quick_reply') NOT NULL DEFAULT 'text',
  body             TEXT,
  media_url        VARCHAR(500) DEFAULT NULL,
  meta             JSON         DEFAULT NULL,
  created_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_conv (conversation_id),
  CONSTRAINT fk_msg_conv FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- LEADS (CRM) ----------
DROP TABLE IF EXISTS leads;
CREATE TABLE leads (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name       VARCHAR(120),
  email           VARCHAR(190),
  phone           VARCHAR(20),
  destination     VARCHAR(120),
  message         TEXT,
  source          VARCHAR(60)  DEFAULT 'web',
  status          ENUM('new','contacted','qualified','converted','lost') NOT NULL DEFAULT 'new',
  assigned_to     INT UNSIGNED DEFAULT NULL,
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- SETTINGS (key-value) ----------
DROP TABLE IF EXISTS settings;
CREATE TABLE settings (
  k   VARCHAR(120) PRIMARY KEY,
  v   TEXT,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- AUDIT LOG ----------
DROP TABLE IF EXISTS audit_log;
CREATE TABLE audit_log (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  actor_id    INT UNSIGNED DEFAULT NULL,
  action      VARCHAR(80)  NOT NULL,
  entity      VARCHAR(40),
  entity_id   INT UNSIGNED DEFAULT NULL,
  meta        JSON,
  ip          VARCHAR(45),
  ua          VARCHAR(255),
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_actor (actor_id), KEY idx_entity (entity, entity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS=1;

-- =============================================================
-- SEED DATA
-- =============================================================

-- Default admin (email: admin@tripoye.com / password: ChangeMe@2026)
-- bcrypt hash for 'ChangeMe@2026'
INSERT INTO users (email, phone, password_hash, full_name, country_code, role, email_verified)
VALUES
('admin@tripoye.com', '+919999999999',
 '$2a$10$rJxnvJgKlVqAJgZBcM4LWuYrjj0J0YjVT3aGqMm4XOG2gKlEh5MOe',
 'TripOye Admin', 'IN', 'super_admin', 1);

-- Countries
INSERT INTO countries (iso2, iso3, name, slug, region, hero_color, description, travel_tips, embassy_notes, is_featured, display_order) VALUES
('AE','ARE','United Arab Emirates','dubai-uae','Middle East','#C2410C',
 'From the gold souks of Deira to the surreal desert dunes outside the city — Dubai is the easiest big-bucket-list trip from India. e-Visa, no embassy visit, decision in days.',
 'Best Nov–Mar. Friday is the holy day; many shops close till afternoon. Carry a light jacket for over-AC malls. Metro is excellent.',
 'Passport must be valid 6+ months from entry. UAE refuses some single females under 22 traveling alone — call us if that''s you.', 1, 10),
('SG','SGP','Singapore','singapore','South-East Asia','#0F766E',
 'Hawker food at midnight, Marina Bay light show, jungle in the middle of the city — a 4-hour flight from Mumbai that feels like crossing continents.',
 'Compact island, MRT goes everywhere. ICA e-visa is fast — most decisions in 5 working days. Cash is fading; bring a card with no FX markup.',
 'Sponsor letter from Singapore relative speeds approval. Older passports with messy entry stamps sometimes trigger extra scrutiny.', 1, 20),
('TH','THA','Thailand','thailand','South-East Asia','#0369A1',
 'Visa-free for short stays for some passports, e-Visa for longer. Bangkok, Chiang Mai, Phuket, Krabi — Thailand still works for ₹50k a week.',
 'Tourist police speak English. ATMs charge ฿220 — withdraw big. Songkran (April) is glorious but everything is wet.',
 'Visa-on-arrival queues at Suvarnabhumi can take 90+ min. e-Visa beats both.', 1, 30),
('JP','JPN','Japan','japan','East Asia','#9A3412',
 'Cherry blossoms, ramen at 2am, shinkansen that arrive to the second. Sticker visa in passport — apply 3 weeks before travel.',
 'IC card (Suica/Pasmo) for everything. Tipping is rude. Spring (Mar–Apr) and autumn (Oct–Nov) are peak.',
 'VFS now handles most Indian applications. Submit detailed day-by-day itinerary — it materially helps approval.', 1, 40),
('US','USA','United States','usa','Americas','#0E1116',
 'The big one. B1/B2 visitor visa is valid 10 years for Indians — worth the effort. Slot wait times have improved dramatically in 2025–26.',
 'NYC, San Francisco, Vegas, Yellowstone. Internal flights are cheap, intercity Amtrak is romantic but slow.',
 'Interview at Mumbai/Delhi/Chennai/Kolkata/Hyderabad. Strong ties to India + clear travel purpose = approval. We do interview prep.', 1, 50),
('GB','GBR','United Kingdom','uk','Europe','#7C2D12',
 'London, Edinburgh, the Lake District. Standard visitor visa is 6 months, but actual stay is at officer''s discretion at port.',
 'Oyster card in London. Trains are pricey unless booked weeks ahead. Tea is real.',
 'UKVI biometrics at VFS. Financial documents are scrutinized heavily — 6 months of statements minimum.', 0, 60),
('FR','FRA','Schengen (France)','schengen-france','Europe','#C2410C',
 'One visa, 27 countries — Paris to Vienna, Reykjavik to Athens. Apply via the country you''ll spend the most days in.',
 'Schengen is multi-entry by default. Travel insurance ≥ €30,000 is mandatory.',
 'France is the most flexible Schengen consulate from India. Germany is the strictest.', 1, 70),
('VN','VNM','Vietnam','vietnam','South-East Asia','#0F766E',
 'Hanoi street food, Ha Long Bay, Hoi An lanterns. Fast e-Visa, no embassy. ₹50k-₹70k a week, easily.',
 'Cash is king outside Hanoi/HCMC. Grab works everywhere. Avoid June–August (rain).',
 'e-Visa for 90 days, single or multiple entry. Print the approval letter — they''ll check at immigration.', 0, 80),
('SA','SAU','Saudi Arabia','saudi-arabia','Middle East','#115E59',
 'Riyadh, Jeddah, AlUla — Saudi quietly opened up for tourism in 2019 and it''s wild how much there is. Easy e-Visa.',
 'Conservative dress for women is no longer enforced but respect goes a long way. Stay hydrated.',
 'e-Visa instant for most nationalities. Hajj/Umrah is a separate category — we handle both.', 0, 90),
('AU','AUS','Australia','australia','Oceania','#C2410C',
 'Sydney to Cairns, Uluru to the Great Ocean Road. Subclass 600 visitor visa, 3-12 months.',
 'Distances are huge — domestic flights add up. Reef is best May–Oct.',
 'No biometrics for most Indian applicants. Form 1419 is the visitor application.', 0, 100),
('CA','CAN','Canada','canada','Americas','#0369A1',
 'Niagara, Banff, Toronto, Vancouver. eTA for some, full visitor visa for Indians — multiple entry up to 10 years.',
 'CAD = INR × ~60. Tim Hortons is a national identity. Cellphone roaming is genuinely expensive — buy a local SIM.',
 'Biometrics at VFS. Strong financial documents help. Approval letter often arrives faster than expected.', 0, 110),
('MY','MYS','Malaysia','malaysia','South-East Asia','#0F766E',
 'KL, Penang, Langkawi, Borneo. eVISA is fast. Mix of Malay, Chinese and Indian culture makes the food extraordinary.',
 'Visa-free for many passports for 30 days. Grab and trains work. Petronas Twin Towers tickets sell out — book ahead.',
 'eVISA single entry valid 3 months. Multiple-entry requires more documentation.', 0, 120);

-- Visa types — Dubai
INSERT INTO visa_types (country_id, code, name, category, validity_days, stay_days, entry_type, processing_min, processing_max, govt_fee, service_fee, approval_rate_pct, interview_required, documents_required, description) VALUES
(1, 'tourist-30d-single', 'Dubai Tourist — 30 days, single entry', 'tourist', 58, 30, 'single', 3, 5, 5200, 1499, 98.50, 0,
 JSON_ARRAY(
   JSON_OBJECT('code','passport',      'name','Passport front page', 'required', true),
   JSON_OBJECT('code','photo',         'name','Recent photo (35×45mm, white bg)', 'required', true),
   JSON_OBJECT('code','flight_ticket', 'name','Confirmed/tentative flight', 'required', false),
   JSON_OBJECT('code','hotel_booking', 'name','Hotel booking', 'required', false)
 ),
 'Most popular Dubai visa. e-Visa delivered by email. No embassy visit. Includes Sharjah, Abu Dhabi, all Emirates.'),
(1, 'tourist-60d-single', 'Dubai Tourist — 60 days, single entry', 'tourist', 58, 60, 'single', 3, 5, 8500, 1999, 97.80, 0, NULL, '60-day visa for longer stays — extensions possible inside UAE.'),
(1, 'tourist-30d-multi',  'Dubai Tourist — 30 days, multi-entry',  'tourist', 90, 30, 'multiple',5, 7, 11500, 2499, 96.50, 0, NULL, 'Multi-entry, valid 90 days from issue.'),
(1, 'transit-96h',         'Dubai Transit — 96 hours',                'transit', 30, 4,  'single', 1, 2, 0, 999, 99.00, 0, NULL, 'For travellers with a layover 8h+ in Dubai.'),
(1, 'business-30d',        'Dubai Business — 30 days',                'business',58, 30, 'single', 3, 5, 7500, 2499, 97.00, 0, NULL, 'Requires UAE host company invitation.');

-- Visa types — Singapore
INSERT INTO visa_types (country_id, code, name, category, validity_days, stay_days, entry_type, processing_min, processing_max, govt_fee, service_fee, approval_rate_pct, interview_required, documents_required, description) VALUES
(2, 'tourist-30d', 'Singapore Tourist e-Visa — 30 days', 'tourist', 60, 30, 'multiple', 5, 7, 2400, 999, 99.20, 0, NULL, 'Multi-entry by default. Fastest e-Visa in Asia.'),
(2, 'business-30d','Singapore Business — 30 days',       'business',60, 30, 'multiple', 5, 7, 2400, 1499, 98.00, 0, NULL, 'Requires letter from Singapore host.');

-- Visa types — Thailand
INSERT INTO visa_types (country_id, code, name, category, validity_days, stay_days, entry_type, processing_min, processing_max, govt_fee, service_fee, approval_rate_pct, documents_required, description) VALUES
(3, 'tourist-60d', 'Thailand Tourist e-Visa — 60 days', 'tourist', 90, 60, 'single', 3, 5, 2500, 1299, 98.80, NULL, 'Standard 60-day tourist visa. Extensions of 30 days available in-country.'),
(3, 'tourist-multi-6m','Thailand Tourist multi-entry — 6 months', 'tourist', 180, 60, 'multiple', 7, 10, 8000, 2499, 96.00, NULL, 'Multiple entries, each up to 60 days.');

-- Visa types — Japan
INSERT INTO visa_types (country_id, code, name, category, validity_days, stay_days, entry_type, processing_min, processing_max, govt_fee, service_fee, approval_rate_pct, documents_required, description) VALUES
(4, 'tourist-15d',   'Japan Tourist — 15 days, single', 'tourist', 90, 15, 'single', 7, 10, 1800, 1499, 96.00, NULL, 'Sticker visa in passport. Detailed itinerary required.'),
(4, 'tourist-multi','Japan Tourist multi-entry — 3 years','tourist', 1095, 30, 'multiple', 10, 14, 3600, 2999, 92.00, NULL, 'For returning visitors — proves stronger profile.');

-- Visa types — USA
INSERT INTO visa_types (country_id, code, name, category, validity_days, stay_days, entry_type, processing_min, processing_max, govt_fee, service_fee, approval_rate_pct, interview_required, documents_required, description) VALUES
(5, 'b1-b2',  'USA B1/B2 Visitor Visa', 'tourist', 3650, 180, 'multiple', 30, 180, 14000, 4999, 78.00, 1, NULL, 'Combined business + tourism. Valid 10 years for Indians. Interview required at consulate.');

-- Visa types — UK
INSERT INTO visa_types (country_id, code, name, category, validity_days, stay_days, entry_type, processing_min, processing_max, govt_fee, service_fee, approval_rate_pct, interview_required, documents_required, description) VALUES
(6, 'visitor-6m', 'UK Standard Visitor Visa — 6 months', 'tourist', 180, 180, 'multiple', 15, 21, 13000, 3499, 87.00, 0, NULL, 'Multi-entry, 6 months. Biometrics at VFS.');

-- Visa types — Schengen
INSERT INTO visa_types (country_id, code, name, category, validity_days, stay_days, entry_type, processing_min, processing_max, govt_fee, service_fee, approval_rate_pct, interview_required, documents_required, description) VALUES
(7, 'short-stay-90d','Schengen Short-Stay (Type C) — 90 days','tourist', 180, 90, 'multiple', 12, 18, 7500, 2999, 92.00, 0, NULL, '90 days in any 180-day rolling window. Travel insurance ≥ €30,000 mandatory.');

-- Visa types — Vietnam
INSERT INTO visa_types (country_id, code, name, category, validity_days, stay_days, entry_type, processing_min, processing_max, govt_fee, service_fee, approval_rate_pct, documents_required, description) VALUES
(8, 'evisa-30d',   'Vietnam e-Visa — 30 days', 'tourist', 90, 30, 'single', 3, 5, 2100, 1199, 99.10, NULL, 'Single entry. Print on A4 and carry.'),
(8, 'evisa-90d',   'Vietnam e-Visa — 90 days, multi', 'tourist', 90, 90, 'multiple', 5, 7, 4200, 1799, 98.00, NULL, 'New in 2023. Multi-entry, 90 days.');

-- Visa types — Saudi
INSERT INTO visa_types (country_id, code, name, category, validity_days, stay_days, entry_type, processing_min, processing_max, govt_fee, service_fee, approval_rate_pct, documents_required, description) VALUES
(9, 'evisa-tourist','Saudi e-Visa Tourist — 1 year', 'tourist', 365, 90, 'multiple', 1, 3, 4500, 1499, 99.50, NULL, 'Instant approval for most nationalities.'),
(9, 'umrah-evisa',  'Umrah e-Visa', 'tourist', 90, 30, 'single', 2, 5, 3000, 1999, 99.00, NULL, 'For Umrah pilgrimage. Separate Hajj process.');

-- Visa types — Australia
INSERT INTO visa_types (country_id, code, name, category, validity_days, stay_days, entry_type, processing_min, processing_max, govt_fee, service_fee, approval_rate_pct, documents_required, description) VALUES
(10, 'visitor-600','Australia Visitor (Subclass 600) — 3 months','tourist', 365, 90, 'multiple', 10, 14, 11500, 2999, 94.00, NULL, 'Standard tourist visa, multi-entry within validity.');

-- Visa types — Canada
INSERT INTO visa_types (country_id, code, name, category, validity_days, stay_days, entry_type, processing_min, processing_max, govt_fee, service_fee, approval_rate_pct, documents_required, description) VALUES
(11, 'visitor-trv','Canada Visitor Visa (TRV) — multi-entry','tourist', 3650, 180, 'multiple', 18, 30, 7700, 3499, 88.00, NULL, 'Up to 10-year validity. Biometrics at VFS.');

-- Visa types — Malaysia
INSERT INTO visa_types (country_id, code, name, category, validity_days, stay_days, entry_type, processing_min, processing_max, govt_fee, service_fee, approval_rate_pct, documents_required, description) VALUES
(12, 'evisa-30d','Malaysia eVISA — 30 days','tourist', 90, 30, 'single', 2, 4, 1800, 999, 98.50, NULL, 'Fast single-entry e-Visa.');

-- Default settings
INSERT INTO settings (k, v) VALUES
('hero_approval_count','142847'),
('default_currency','INR'),
('whatsapp_greeting','Hi! I am Noor 🌿 your TripOye visa assistant. Where are you headed?'),
('homepage_announcement','New: Saudi e-Visa now instant. Schengen processing improved to 12 days.');

/**
 * Hostinger Node.js entry shim.
 * Hostinger's Express preset boots index.js by convention.
 * Delegating to server.js (the real entry point) keeps everything intact.
 */
require('./server.js');

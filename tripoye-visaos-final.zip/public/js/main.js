/* TripOye VisaOS — client JS */
(function () {
  'use strict';

  // ---------- Noor chat widget ----------
  const panel = document.getElementById('noor-panel');
  const cta   = document.getElementById('wa-cta');
  const form  = document.getElementById('noor-form');
  const input = document.getElementById('noor-input');
  const messagesEl = document.getElementById('noor-messages');
  const history = [];
  let convId = null;

  function bubble(role, html) {
    const cls = role === 'user'
      ? 'bg-ink-900 text-paper-50 rounded-tr-sm ml-auto'
      : 'bg-white text-ink-900 rounded-tl-sm border border-paper-200';
    const div = document.createElement('div');
    div.className = `${cls} rounded-2xl px-3 py-2.5 max-w-[88%] block whitespace-pre-wrap`;
    div.innerHTML = html;
    const wrap = document.createElement('div');
    wrap.className = role === 'user' ? 'flex justify-end' : 'flex';
    wrap.appendChild(div);
    messagesEl.appendChild(wrap);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function typingOn() {
    const t = document.createElement('div');
    t.id = 'noor-typing';
    t.className = 'flex';
    t.innerHTML = '<div class="bg-white rounded-2xl rounded-tl-sm border border-paper-200 px-3 py-2.5 text-[13px]"><span class="typing"><span>·</span><span>·</span><span>·</span></span></div>';
    messagesEl.appendChild(t);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }
  function typingOff() { const t = document.getElementById('noor-typing'); if (t) t.remove(); }

  window.tripoyeChat = {
    open()  { if (panel) panel.classList.remove('hidden'); if (cta) cta.style.display = 'none'; setTimeout(() => input && input.focus(), 100); },
    close() { if (panel) panel.classList.add('hidden'); if (cta) cta.style.display = ''; }
  };

  if (form) {
    form.addEventListener('submit', async e => {
      e.preventDefault();
      const text = (input.value || '').trim();
      if (!text) return;
      input.value = '';
      bubble('user', escapeHtml(text));
      history.push({ role: 'user', content: text });
      typingOn();
      try {
        const res = await fetch('/api/chat', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ messages: history, conversation_id: convId }),
        });
        const data = await res.json();
        typingOff();
        if (data.ok) {
          convId = data.conversation_id || convId;
          bubble('ai', escapeHtml(data.reply));
          history.push({ role: 'assistant', content: data.reply });
        } else {
          bubble('ai', '<span class="text-rose-600">Sorry — something went wrong. Please try again.</span>');
        }
      } catch (e) {
        typingOff();
        bubble('ai', '<span class="text-rose-600">Connection issue. Please try again in a moment.</span>');
      }
    });
  }

  // ---------- Approvals counter tick ----------
  const counter = document.getElementById('approval-count');
  if (counter) {
    let n = parseInt(counter.textContent.replace(/[^\d]/g, ''), 10) || 142847;
    setInterval(() => { n += Math.floor(Math.random() * 3) + 1; counter.textContent = n.toLocaleString('en-IN'); }, 4200);
  }

  // ---------- Country chip → search ----------
  document.querySelectorAll('[data-fill-country]').forEach(btn => {
    btn.addEventListener('click', () => {
      const input = document.querySelector('[data-country-input]');
      if (input) { input.value = btn.dataset.fillCountry; input.focus(); }
    });
  });

  // ---------- Utility ----------
  function escapeHtml(s) {
    return String(s || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }
})();

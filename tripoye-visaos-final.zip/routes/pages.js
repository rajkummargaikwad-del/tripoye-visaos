const express = require('express');
const router = express.Router();
const db = require('../db');
const { requireLogin } = require('../middleware/auth');

// ---------- Home ----------
router.get('/', async (req, res) => {
  const featured = await db.query(
    `SELECT c.*, v.govt_fee + v.service_fee AS starting_fee, v.processing_min, v.processing_max, v.approval_rate_pct
     FROM countries c
     LEFT JOIN visa_types v ON v.country_id = c.id AND v.is_active = 1
     WHERE c.is_featured = 1 AND c.is_active = 1
     GROUP BY c.id
     ORDER BY c.display_order LIMIT 4`);
  const more = await db.query(
    `SELECT iso2, slug, name FROM countries WHERE is_active = 1 AND is_featured = 0 ORDER BY display_order LIMIT 6`);
  const setting = await db.one("SELECT v FROM settings WHERE k = 'hero_approval_count'");
  res.render('home', {
    page: { title: 'TripOye VisaOS — Apply Any Visa, Anywhere', active: '' },
    featured, more,
    approvalCount: parseInt(setting?.v || '142847', 10),
  });
});

// ---------- Countries listing ----------
router.get('/countries', async (req, res) => {
  const q = (req.query.q || '').trim();
  const cat = (req.query.cat || '').trim();
  let sql = `SELECT c.*, MIN(v.govt_fee + v.service_fee) AS starting_fee, MIN(v.processing_min) AS pmin, MAX(v.processing_max) AS pmax, AVG(v.approval_rate_pct) AS avg_approval
             FROM countries c LEFT JOIN visa_types v ON v.country_id = c.id AND v.is_active = 1
             WHERE c.is_active = 1`;
  const params = [];
  if (q)   { sql += ' AND (c.name LIKE ? OR c.region LIKE ?)'; params.push(`%${q}%`, `%${q}%`); }
  if (cat) { sql += ' AND EXISTS (SELECT 1 FROM visa_types vt WHERE vt.country_id = c.id AND vt.category = ? AND vt.is_active = 1)'; params.push(cat); }
  sql += ' GROUP BY c.id ORDER BY c.display_order';
  const countries = await db.query(sql, params);
  res.render('countries', { page: { title: 'All visa destinations · TripOye', active:'countries' }, countries, q, cat });
});

// ---------- Country detail ----------
router.get('/country/:slug', async (req, res, next) => {
  const country = await db.one(`SELECT * FROM countries WHERE slug = ? AND is_active = 1`, [req.params.slug]);
  if (!country) return next();
  const visaTypes = await db.query(`SELECT * FROM visa_types WHERE country_id = ? AND is_active = 1 ORDER BY service_fee`, [country.id]);
  res.render('country', { page: { title: `${country.name} visa · TripOye`, active:'countries' }, country, visaTypes });
});

// ---------- Eligibility checker ----------
router.get('/eligibility', async (req, res) => {
  const countries = await db.query(`SELECT id, iso2, name, slug FROM countries WHERE is_active = 1 ORDER BY display_order`);
  res.render('eligibility', { page: { title: 'AI Eligibility Checker · TripOye', active:'eligibility' }, countries });
});

// ---------- Pricing ----------
router.get('/pricing', (req, res) => {
  res.render('pricing', { page: { title:'Pricing · TripOye', active:'pricing' } });
});

// ---------- About ----------
router.get('/about', (req, res) => {
  res.render('about', { page: { title:'About · TripOye', active:'about' } });
});

// ---------- Contact ----------
router.get('/contact', (req, res) => {
  res.render('contact', { page: { title:'Contact · TripOye', active:'contact' } });
});

router.post('/contact', async (req, res) => {
  const { name, email, phone, destination, message } = req.body;
  if (!name || !email || !message) {
    req.session.flash = { type:'error', msg:'Please fill name, email and message.' };
    return res.redirect('/contact');
  }
  await db.insert(
    `INSERT INTO leads (full_name, email, phone, destination, message, source) VALUES (?, ?, ?, ?, ?, 'contact_form')`,
    [name, email, phone || null, destination || null, message]
  );
  req.session.flash = { type:'success', msg:'Got it 🌿 We\'ll get back within 30 minutes.' };
  res.redirect('/contact');
});

// ---------- Apply (must be logged in) ----------
router.get('/apply', requireLogin, async (req, res) => {
  const countries = await db.query(`SELECT id, iso2, slug, name FROM countries WHERE is_active = 1 ORDER BY display_order`);
  const visaTypeId = req.query.visa_type ? parseInt(req.query.visa_type, 10) : null;
  let preselected = null;
  if (visaTypeId) {
    preselected = await db.one(`SELECT v.*, c.name AS country_name, c.iso2 FROM visa_types v JOIN countries c ON c.id = v.country_id WHERE v.id = ?`, [visaTypeId]);
  }
  res.render('apply', { page: { title:'Start application · TripOye', active:'' }, countries, preselected });
});

// ---------- Dashboard ----------
router.get('/dashboard', requireLogin, async (req, res) => {
  const apps = await db.query(
    `SELECT a.*, c.name AS country_name, c.iso2, v.name AS visa_name
     FROM applications a
     JOIN countries c   ON c.id = a.country_id
     JOIN visa_types v  ON v.id = a.visa_type_id
     WHERE a.user_id = ?
     ORDER BY a.created_at DESC`, [req.user.id]);
  res.render('dashboard', { page: { title:'My applications · TripOye', active:'' }, apps });
});

// ---------- Track an application ----------
router.get('/track', (req, res) => {
  res.render('track-search', { page: { title:'Track your visa · TripOye', active:'' }, result: null, err: null });
});

router.post('/track', async (req, res) => {
  const code = (req.body.ref_code || '').trim().toUpperCase();
  if (!code) return res.render('track-search', { page:{ title:'Track · TripOye' }, result:null, err:'Enter a reference code.' });
  const app = await db.one(
    `SELECT a.*, c.name AS country_name, c.iso2, v.name AS visa_name, u.full_name
     FROM applications a
     JOIN countries c   ON c.id = a.country_id
     JOIN visa_types v  ON v.id = a.visa_type_id
     JOIN users u       ON u.id = a.user_id
     WHERE a.ref_code = ? LIMIT 1`, [code]);
  if (!app) return res.render('track-search', { page:{ title:'Track · TripOye' }, result:null, err:`No application found with code "${code}".` });
  res.render('track-search', { page:{ title:`Track ${code} · TripOye` }, result: app, err: null });
});

router.get('/track/:code', async (req, res, next) => {
  const app = await db.one(
    `SELECT a.*, c.name AS country_name, c.iso2, v.name AS visa_name, u.full_name
     FROM applications a JOIN countries c ON c.id=a.country_id JOIN visa_types v ON v.id=a.visa_type_id JOIN users u ON u.id=a.user_id
     WHERE a.ref_code = ?`, [req.params.code.toUpperCase()]);
  if (!app) return next();
  res.render('track-search', { page:{ title:`Track ${app.ref_code} · TripOye` }, result: app, err: null });
});

// ---------- WhatsApp landing ----------
router.get('/whatsapp', (req, res) => {
  res.render('whatsapp', { page:{ title:'Apply on WhatsApp · TripOye', active:'' } });
});

module.exports = router;

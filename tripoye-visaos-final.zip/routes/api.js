const express = require('express');
const router = express.Router();
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const db = require('../db');
const config = require('../config');
const { requireLogin } = require('../middleware/auth');
const openai = require('../services/openai');
const whatsapp = require('../services/whatsapp');
const ocr = require('../services/ocr');
const razorpay = require('../services/razorpay');

// ---------- Multer for uploads ----------
const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const dir = path.join(__dirname, '..', 'public', 'uploads', 'docs');
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      cb(null, dir);
    },
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase();
      cb(null, Date.now() + '_' + crypto.randomBytes(6).toString('hex') + ext);
    }
  }),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = ['.jpg','.jpeg','.png','.pdf'];
    cb(allowed.includes(path.extname(file.originalname).toLowerCase()) ? null : new Error('Invalid file type'), true);
  }
});

// ============================================================
//  NOOR — AI Chat (web)
// ============================================================
router.post('/chat', async (req, res) => {
  const { messages = [], conversation_id = null } = req.body;
  if (!Array.isArray(messages) || !messages.length) {
    return res.status(400).json({ ok:false, error:'messages required' });
  }
  try {
    const reply = await openai.chat(messages);
    // persist if there's a logged-in user (optional)
    if (req.user) {
      let convId = conversation_id;
      if (!convId) {
        convId = await db.insert(
          `INSERT INTO conversations (user_id, channel, ai_persona, language, status) VALUES (?, 'web', 'noor', 'en', 'open')`,
          [req.user.id]
        );
      }
      const last = messages[messages.length - 1];
      if (last?.role === 'user') {
        await db.insert(`INSERT INTO messages (conversation_id, sender, message_type, body) VALUES (?, 'user','text', ?)`, [convId, last.content || '']);
      }
      await db.insert(`INSERT INTO messages (conversation_id, sender, message_type, body) VALUES (?, 'ai','text', ?)`, [convId, reply]);
      return res.json({ ok:true, reply, conversation_id: convId });
    }
    res.json({ ok:true, reply });
  } catch (e) {
    console.error('chat error', e);
    res.status(500).json({ ok:false, error: 'Chat error' });
  }
});

// ============================================================
//  Eligibility checker
// ============================================================
router.post('/eligibility', async (req, res) => {
  try {
    const out = await openai.scoreEligibility(req.body || {});
    res.json({ ok:true, ...out });
  } catch (e) {
    console.error('eligibility error', e);
    res.status(500).json({ ok:false, error:'Could not score eligibility' });
  }
});

// ============================================================
//  Submit application
// ============================================================
router.post('/application', requireLogin, async (req, res) => {
  try {
    const { visa_type_id, travel_date, return_date, num_travellers, purpose, form_data, channel } = req.body;
    if (!visa_type_id) return res.status(400).json({ ok:false, error:'visa_type_id required' });

    const vt = await db.one(
      `SELECT v.*, c.id AS country_id FROM visa_types v JOIN countries c ON c.id = v.country_id WHERE v.id = ? AND v.is_active = 1`,
      [visa_type_id]
    );
    if (!vt) return res.status(404).json({ ok:false, error:'Visa type not found' });

    const refCode = 'TO-' + crypto.randomBytes(4).toString('hex').toUpperCase();
    const total   = parseFloat(vt.govt_fee) + parseFloat(vt.service_fee);

    const appId = await db.insert(
      `INSERT INTO applications
        (ref_code, user_id, country_id, visa_type_id, status, travel_date, return_date,
         num_travellers, purpose, form_data, amount_total, currency, channel)
       VALUES (?, ?, ?, ?, 'draft', ?, ?, ?, ?, ?, ?, ?, ?)`,
      [refCode, req.user.id, vt.country_id, visa_type_id,
       travel_date || null, return_date || null, num_travellers || 1, purpose || null,
       JSON.stringify(form_data || {}), total, vt.currency || 'INR', channel || 'web']
    );

    res.json({ ok:true, ref_code: refCode, application_id: appId, amount: total });
  } catch (e) {
    console.error('application create error', e);
    res.status(500).json({ ok:false, error:'Could not create application' });
  }
});

// Update form_data on an existing draft
router.patch('/application/:id', requireLogin, async (req, res) => {
  const app = await db.one('SELECT id, user_id, status FROM applications WHERE id = ?', [req.params.id]);
  if (!app || app.user_id !== req.user.id) return res.status(404).json({ ok:false, error:'Not found' });
  if (!['draft','in_review'].includes(app.status)) return res.status(400).json({ ok:false, error:'Application is locked' });
  const { form_data, purpose, travel_date, return_date, num_travellers } = req.body;
  await db.exec(
    `UPDATE applications SET form_data = COALESCE(?, form_data), purpose = COALESCE(?, purpose),
       travel_date = COALESCE(?, travel_date), return_date = COALESCE(?, return_date),
       num_travellers = COALESCE(?, num_travellers) WHERE id = ?`,
    [form_data ? JSON.stringify(form_data) : null, purpose || null, travel_date || null, return_date || null, num_travellers || null, app.id]
  );
  res.json({ ok:true });
});

// Submit (move draft -> submitted)
router.post('/application/:id/submit', requireLogin, async (req, res) => {
  const app = await db.one('SELECT id, user_id, status FROM applications WHERE id = ?', [req.params.id]);
  if (!app || app.user_id !== req.user.id) return res.status(404).json({ ok:false, error:'Not found' });
  if (app.status !== 'draft') return res.status(400).json({ ok:false, error:'Already submitted' });
  await db.exec("UPDATE applications SET status = 'submitted', submitted_at = NOW() WHERE id = ?", [app.id]);
  res.json({ ok:true });
});

// ============================================================
//  Document upload + OCR
// ============================================================
router.post('/upload', requireLogin, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ ok:false, error:'No file uploaded' });
    const { application_id, doc_type = 'passport' } = req.body;
    const relPath = '/uploads/docs/' + path.basename(req.file.path);

    // Validate this application belongs to user
    let appId = null;
    if (application_id) {
      const a = await db.one('SELECT id FROM applications WHERE id = ? AND user_id = ?', [application_id, req.user.id]);
      if (!a) return res.status(403).json({ ok:false, error:'Application not yours' });
      appId = a.id;
    }

    let ocrData = null;
    if (doc_type === 'passport') {
      ocrData = await ocr.parsePassport(req.file.path);
    }

    if (appId) {
      await db.insert(
        `INSERT INTO documents (application_id, doc_type, original_name, storage_path, mime_type, size_bytes, ocr_data, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'uploaded')`,
        [appId, doc_type, req.file.originalname, relPath, req.file.mimetype, req.file.size, ocrData ? JSON.stringify(ocrData) : null]
      );
    }

    res.json({ ok:true, url: relPath, ocr: ocrData });
  } catch (e) {
    console.error('upload error', e);
    res.status(500).json({ ok:false, error: e.message || 'Upload failed' });
  }
});

// ============================================================
//  Payment — Razorpay order
// ============================================================
router.post('/payment/razorpay/order', requireLogin, async (req, res) => {
  try {
    const { application_id } = req.body;
    const app = await db.one('SELECT * FROM applications WHERE id = ? AND user_id = ?', [application_id, req.user.id]);
    if (!app) return res.status(404).json({ ok:false, error:'Application not found' });

    const order = await razorpay.createOrder({
      amount: parseFloat(app.amount_total),
      currency: app.currency || 'INR',
      receipt: app.ref_code,
      notes: { application_id: app.id, ref_code: app.ref_code },
    });
    await db.insert(
      `INSERT INTO payments (application_id, user_id, gateway, gateway_order_id, amount, currency, status)
       VALUES (?, ?, 'razorpay', ?, ?, ?, 'pending')`,
      [app.id, req.user.id, order.id, app.amount_total, app.currency || 'INR']
    );
    res.json({ ok:true, order, key_id: config.razorpay.keyId });
  } catch (e) {
    console.error('razorpay order error', e);
    res.status(500).json({ ok:false, error:'Could not create order' });
  }
});

// Razorpay verification (called from client after payment)
router.post('/payment/razorpay/verify', requireLogin, async (req, res) => {
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature, application_id } = req.body;
  const ok = razorpay.verifySignature({ orderId: razorpay_order_id, paymentId: razorpay_payment_id, signature: razorpay_signature });
  if (!ok && config.features.razorpay) return res.status(400).json({ ok:false, error:'Bad signature' });

  await db.exec(
    `UPDATE payments SET status = 'paid', gateway_payment_id = ? WHERE gateway_order_id = ?`,
    [razorpay_payment_id, razorpay_order_id]
  );
  await db.exec("UPDATE applications SET amount_paid = amount_total, status = IF(status='draft','submitted',status), submitted_at = COALESCE(submitted_at, NOW()) WHERE id = ?", [application_id]);

  res.json({ ok:true });
});

// ============================================================
//  WhatsApp webhook
// ============================================================
router.get('/whatsapp/webhook', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];
  if (mode === 'subscribe' && token === config.whatsapp.verifyToken) return res.send(challenge);
  res.sendStatus(403);
});

router.post('/whatsapp/webhook', async (req, res) => {
  res.sendStatus(200);  // ack immediately — Meta retries on timeout
  try {
    const msg = whatsapp.parseIncoming(req.body);
    if (!msg) return;

    // find/create conversation
    let conv = await db.one('SELECT * FROM conversations WHERE channel = ? AND external_id = ? LIMIT 1', ['whatsapp', msg.from]);
    if (!conv) {
      const id = await db.insert(
        `INSERT INTO conversations (channel, external_id, ai_persona, language, status) VALUES ('whatsapp', ?, 'noor', 'en', 'open')`,
        [msg.from]
      );
      conv = { id };
    }
    await db.insert(
      `INSERT INTO messages (conversation_id, sender, message_type, body) VALUES (?, 'user', ?, ?)`,
      [conv.id, msg.type || 'text', msg.text || '']
    );

    // load last few messages for context
    const history = await db.query(
      `SELECT sender, body FROM messages WHERE conversation_id = ? ORDER BY id DESC LIMIT 12`,
      [conv.id]
    );
    const formatted = history.reverse().map(m => ({ role: m.sender === 'user' ? 'user' : 'assistant', content: m.body || '' }));

    const reply = await openai.chat(formatted);
    await db.insert(`INSERT INTO messages (conversation_id, sender, message_type, body) VALUES (?, 'ai','text', ?)`, [conv.id, reply]);
    await whatsapp.sendText(msg.from, reply);
  } catch (e) {
    console.error('WA webhook error', e);
  }
});

// ============================================================
//  Misc
// ============================================================
router.get('/visa-types/:countryId', async (req, res) => {
  const types = await db.query('SELECT * FROM visa_types WHERE country_id = ? AND is_active = 1 ORDER BY service_fee', [req.params.countryId]);
  res.json({ ok:true, types });
});

router.get('/countries/search', async (req, res) => {
  const q = '%' + (req.query.q || '') + '%';
  const rows = await db.query('SELECT id, iso2, slug, name FROM countries WHERE is_active = 1 AND name LIKE ? LIMIT 8', [q]);
  res.json({ ok:true, rows });
});

module.exports = router;

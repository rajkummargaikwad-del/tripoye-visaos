const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../db');
const { requireAdmin } = require('../middleware/auth');

// Every admin route requires admin
router.use(requireAdmin);

// ---------- Dashboard ----------
router.get('/', async (req, res) => {
  const [users, apps, leads, payments, recent, statusBreakdown] = await Promise.all([
    db.one("SELECT COUNT(*) c, SUM(role='user') u FROM users WHERE status='active'"),
    db.one("SELECT COUNT(*) c, SUM(status='approved') a, SUM(status='in_review' OR status='submitted') pending FROM applications"),
    db.one("SELECT COUNT(*) c, SUM(status='new') new FROM leads"),
    db.one("SELECT COALESCE(SUM(amount),0) total FROM payments WHERE status='paid'"),
    db.query(`SELECT a.*, c.name AS country_name, c.iso2, v.name AS visa_name, u.full_name AS user_name
              FROM applications a JOIN countries c ON c.id=a.country_id JOIN visa_types v ON v.id=a.visa_type_id JOIN users u ON u.id=a.user_id
              ORDER BY a.created_at DESC LIMIT 10`),
    db.query(`SELECT status, COUNT(*) c FROM applications GROUP BY status`),
  ]);
  res.render('admin/dashboard', {
    page:{ title:'Admin · TripOye', active:'dashboard' },
    stats:{ users, apps, leads, payments }, recent, statusBreakdown
  });
});

// ============================================================
//  Countries master
// ============================================================
router.get('/countries', async (req, res) => {
  const countries = await db.query(`SELECT c.*, (SELECT COUNT(*) FROM visa_types v WHERE v.country_id = c.id) AS visa_count
                                    FROM countries c ORDER BY c.display_order`);
  res.render('admin/countries', { page:{ title:'Countries · Admin', active:'countries' }, countries });
});

router.get('/countries/new', (req, res) => {
  res.render('admin/country-edit', { page:{ title:'New country · Admin', active:'countries' }, country: {}, mode:'new' });
});

router.post('/countries/new', async (req, res) => {
  const { iso2, iso3, name, slug, region, hero_color, description, travel_tips, embassy_notes, is_featured, is_active, display_order } = req.body;
  await db.insert(
    `INSERT INTO countries (iso2, iso3, name, slug, region, hero_color, description, travel_tips, embassy_notes, is_featured, is_active, display_order)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
    [iso2, iso3 || null, name, slug, region || null, hero_color || '#C2410C', description, travel_tips, embassy_notes,
     is_featured ? 1 : 0, is_active ? 1 : 0, parseInt(display_order || 100, 10)]
  );
  req.session.flash = { type:'success', msg:'Country created.' };
  res.redirect('/admin/countries');
});

router.get('/countries/:id', async (req, res, next) => {
  const country = await db.one('SELECT * FROM countries WHERE id = ?', [req.params.id]);
  if (!country) return next();
  const visaTypes = await db.query('SELECT * FROM visa_types WHERE country_id = ? ORDER BY service_fee', [country.id]);
  res.render('admin/country-edit', { page:{ title:`${country.name} · Admin`, active:'countries' }, country, visaTypes, mode:'edit' });
});

router.post('/countries/:id', async (req, res) => {
  const { iso2, iso3, name, slug, region, hero_color, description, travel_tips, embassy_notes, is_featured, is_active, display_order } = req.body;
  await db.exec(
    `UPDATE countries SET iso2=?, iso3=?, name=?, slug=?, region=?, hero_color=?, description=?, travel_tips=?, embassy_notes=?,
       is_featured=?, is_active=?, display_order=? WHERE id = ?`,
    [iso2, iso3 || null, name, slug, region || null, hero_color || '#C2410C', description, travel_tips, embassy_notes,
     is_featured ? 1 : 0, is_active ? 1 : 0, parseInt(display_order || 100, 10), req.params.id]
  );
  req.session.flash = { type:'success', msg:'Country updated.' };
  res.redirect('/admin/countries/' + req.params.id);
});

router.post('/countries/:id/delete', async (req, res) => {
  await db.exec('DELETE FROM countries WHERE id = ?', [req.params.id]);
  req.session.flash = { type:'success', msg:'Country deleted.' };
  res.redirect('/admin/countries');
});

// ============================================================
//  Visa types master
// ============================================================
router.post('/visa-types/new', async (req, res) => {
  const v = req.body;
  await db.insert(
    `INSERT INTO visa_types (country_id, code, name, category, validity_days, stay_days, entry_type, processing_min, processing_max,
       govt_fee, service_fee, currency, interview_required, appointment_required, approval_rate_pct, description, is_active)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1)`,
    [v.country_id, v.code, v.name, v.category, v.validity_days || 30, v.stay_days || 30, v.entry_type || 'single',
     v.processing_min || 5, v.processing_max || 10, v.govt_fee || 0, v.service_fee || 1499, v.currency || 'INR',
     v.interview_required ? 1 : 0, v.appointment_required ? 1 : 0, v.approval_rate_pct || 95, v.description || null]
  );
  req.session.flash = { type:'success', msg:'Visa type added.' };
  res.redirect('/admin/countries/' + v.country_id);
});

router.post('/visa-types/:id/delete', async (req, res) => {
  const vt = await db.one('SELECT country_id FROM visa_types WHERE id = ?', [req.params.id]);
  await db.exec('DELETE FROM visa_types WHERE id = ?', [req.params.id]);
  res.redirect('/admin/countries/' + (vt?.country_id || ''));
});

router.post('/visa-types/:id', async (req, res) => {
  const v = req.body;
  await db.exec(
    `UPDATE visa_types SET name=?, category=?, validity_days=?, stay_days=?, entry_type=?, processing_min=?, processing_max=?,
       govt_fee=?, service_fee=?, approval_rate_pct=?, description=?, is_active=? WHERE id = ?`,
    [v.name, v.category, v.validity_days || 30, v.stay_days || 30, v.entry_type, v.processing_min, v.processing_max,
     v.govt_fee, v.service_fee, v.approval_rate_pct, v.description, v.is_active ? 1 : 0, req.params.id]
  );
  res.redirect('back');
});

// ============================================================
//  Applications
// ============================================================
router.get('/applications', async (req, res) => {
  const status = req.query.status || '';
  let sql = `SELECT a.*, c.name AS country_name, c.iso2, v.name AS visa_name, u.full_name AS user_name, u.email AS user_email
             FROM applications a JOIN countries c ON c.id=a.country_id JOIN visa_types v ON v.id=a.visa_type_id JOIN users u ON u.id=a.user_id`;
  const params = [];
  if (status) { sql += ' WHERE a.status = ?'; params.push(status); }
  sql += ' ORDER BY a.created_at DESC LIMIT 200';
  const apps = await db.query(sql, params);
  res.render('admin/applications', { page:{ title:'Applications · Admin', active:'applications' }, apps, statusFilter:status });
});

router.get('/applications/:id', async (req, res, next) => {
  const app = await db.one(
    `SELECT a.*, c.name AS country_name, c.iso2, v.name AS visa_name, v.govt_fee, v.service_fee,
            u.full_name AS user_name, u.email AS user_email, u.phone AS user_phone
     FROM applications a JOIN countries c ON c.id=a.country_id JOIN visa_types v ON v.id=a.visa_type_id JOIN users u ON u.id=a.user_id
     WHERE a.id = ?`, [req.params.id]
  );
  if (!app) return next();
  const docs = await db.query('SELECT * FROM documents WHERE application_id = ? ORDER BY uploaded_at DESC', [app.id]);
  const pays = await db.query('SELECT * FROM payments WHERE application_id = ? ORDER BY created_at DESC', [app.id]);
  res.render('admin/application-detail', {
    page:{ title:`${app.ref_code} · Admin`, active:'applications' }, app, docs, pays,
  });
});

router.post('/applications/:id/status', async (req, res) => {
  const { status, notes_internal } = req.body;
  const allowed = ['draft','submitted','in_review','verified','sent_to_embassy','approved','rejected','cancelled'];
  if (!allowed.includes(status)) return res.status(400).send('Invalid status');
  await db.exec(
    `UPDATE applications SET status = ?, notes_internal = ?, decided_at = IF(? IN ('approved','rejected'), NOW(), decided_at) WHERE id = ?`,
    [status, notes_internal || null, status, req.params.id]
  );
  req.session.flash = { type:'success', msg:'Status updated.' };
  res.redirect('/admin/applications/' + req.params.id);
});

// ============================================================
//  Users
// ============================================================
router.get('/users', async (req, res) => {
  const users = await db.query(
    `SELECT u.*, (SELECT COUNT(*) FROM applications a WHERE a.user_id = u.id) AS app_count
     FROM users u ORDER BY u.created_at DESC LIMIT 300`);
  res.render('admin/users', { page:{ title:'Users · Admin', active:'users' }, users });
});

router.post('/users/:id/role', async (req, res) => {
  const allowed = ['user','agent','admin','super_admin'];
  if (!allowed.includes(req.body.role)) return res.status(400).send('Bad role');
  if (req.user.role !== 'super_admin' && req.body.role === 'super_admin') return res.status(403).send('Forbidden');
  await db.exec('UPDATE users SET role = ? WHERE id = ?', [req.body.role, req.params.id]);
  res.redirect('/admin/users');
});

router.post('/users/:id/status', async (req, res) => {
  await db.exec('UPDATE users SET status = ? WHERE id = ?', [req.body.status, req.params.id]);
  res.redirect('/admin/users');
});

// ============================================================
//  Leads (CRM)
// ============================================================
router.get('/leads', async (req, res) => {
  const leads = await db.query('SELECT * FROM leads ORDER BY created_at DESC LIMIT 300');
  res.render('admin/leads', { page:{ title:'Leads · Admin', active:'leads' }, leads });
});

router.post('/leads/:id/status', async (req, res) => {
  await db.exec('UPDATE leads SET status = ? WHERE id = ?', [req.body.status, req.params.id]);
  res.redirect('/admin/leads');
});

// ============================================================
//  Conversations (AI chats)
// ============================================================
router.get('/conversations', async (req, res) => {
  const convs = await db.query(
    `SELECT cv.*, u.full_name, u.email, (SELECT body FROM messages m WHERE m.conversation_id = cv.id ORDER BY id DESC LIMIT 1) AS last_message,
       (SELECT COUNT(*) FROM messages m WHERE m.conversation_id = cv.id) AS msg_count
     FROM conversations cv LEFT JOIN users u ON u.id = cv.user_id
     ORDER BY cv.updated_at DESC LIMIT 100`);
  res.render('admin/conversations', { page:{ title:'Conversations · Admin', active:'conversations' }, convs });
});

router.get('/conversations/:id', async (req, res, next) => {
  const conv = await db.one('SELECT cv.*, u.full_name, u.email FROM conversations cv LEFT JOIN users u ON u.id = cv.user_id WHERE cv.id = ?', [req.params.id]);
  if (!conv) return next();
  const msgs = await db.query('SELECT * FROM messages WHERE conversation_id = ? ORDER BY id', [conv.id]);
  res.render('admin/conversation-detail', { page:{ title:`Conversation #${conv.id}`, active:'conversations' }, conv, msgs });
});

// ============================================================
//  Settings
// ============================================================
router.get('/settings', async (req, res) => {
  const settings = await db.query('SELECT * FROM settings');
  const config = require('../config');
  res.render('admin/settings', { page:{ title:'Settings · Admin', active:'settings' }, settings, cfg: config });
});

router.post('/settings', async (req, res) => {
  for (const [k, v] of Object.entries(req.body)) {
    if (typeof v !== 'string') continue;
    await db.exec(
      'INSERT INTO settings (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)',
      [k, v]
    );
  }
  req.session.flash = { type:'success', msg:'Settings saved.' };
  res.redirect('/admin/settings');
});

// Change own password
router.post('/me/password', async (req, res) => {
  const { current, fresh } = req.body;
  if (!fresh || fresh.length < 8) {
    req.session.flash = { type:'error', msg:'New password must be ≥ 8 chars.' };
    return res.redirect('/admin/settings');
  }
  const u = await db.one('SELECT password_hash FROM users WHERE id = ?', [req.user.id]);
  if (!(await bcrypt.compare(current || '', u.password_hash))) {
    req.session.flash = { type:'error', msg:'Current password is wrong.' };
    return res.redirect('/admin/settings');
  }
  const hash = await bcrypt.hash(fresh, 10);
  await db.exec('UPDATE users SET password_hash = ? WHERE id = ?', [hash, req.user.id]);
  req.session.flash = { type:'success', msg:'Password updated.' };
  res.redirect('/admin/settings');
});

module.exports = router;

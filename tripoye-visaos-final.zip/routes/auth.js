const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../db');
const email = require('../services/email');

// ---------- Signup ----------
router.get('/signup', (req, res) => {
  res.render('signup', { page:{ title:'Create account · TripOye' }, err:null, form:{} });
});

router.post('/signup', async (req, res) => {
  const { full_name, email: addr, phone, password } = req.body;
  const form = { full_name, email: addr, phone };

  if (!full_name || !addr || !password) {
    return res.render('signup', { page:{title:'Create account · TripOye'}, err:'Please fill all required fields.', form });
  }
  if (password.length < 8) {
    return res.render('signup', { page:{title:'Create account · TripOye'}, err:'Password must be at least 8 characters.', form });
  }
  const existing = await db.one('SELECT id FROM users WHERE email = ?', [addr.toLowerCase()]);
  if (existing) {
    return res.render('signup', { page:{title:'Create account · TripOye'}, err:'An account with that email already exists.', form });
  }
  const hash = await bcrypt.hash(password, 10);
  const uid = await db.insert(
    `INSERT INTO users (email, phone, password_hash, full_name, role) VALUES (?, ?, ?, ?, 'user')`,
    [addr.toLowerCase(), phone || null, hash, full_name]
  );
  req.session.userId = uid;

  try { await email.sendWelcome({ email: addr, full_name }); } catch {}

  const next = req.query.next || '/dashboard';
  res.redirect(next);
});

// ---------- Login ----------
router.get('/login', (req, res) => {
  res.render('login', { page:{ title:'Sign in · TripOye' }, err:null, form:{} });
});

router.post('/login', async (req, res) => {
  const { email: addr, password } = req.body;
  if (!addr || !password) {
    return res.render('login', { page:{title:'Sign in · TripOye'}, err:'Please enter email and password.', form:{ email: addr } });
  }
  const user = await db.one(
    "SELECT id, password_hash, role, status FROM users WHERE email = ? LIMIT 1",
    [addr.toLowerCase()]
  );
  if (!user || user.status !== 'active' || !(await bcrypt.compare(password, user.password_hash))) {
    return res.render('login', { page:{title:'Sign in · TripOye'}, err:'Invalid email or password.', form:{ email: addr } });
  }
  req.session.userId = user.id;
  await db.exec('UPDATE users SET last_login_at = NOW() WHERE id = ?', [user.id]);

  const next = req.body.next_url || req.query.next ||
    (['admin','super_admin'].includes(user.role) ? '/admin' : '/dashboard');
  res.redirect(next);
});

// ---------- Logout ----------
router.get('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/'));
});

module.exports = router;
